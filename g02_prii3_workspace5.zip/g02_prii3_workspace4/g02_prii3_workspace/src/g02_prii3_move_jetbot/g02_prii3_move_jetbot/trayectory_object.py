import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from gazebo_msgs.srv import SpawnEntity, DeleteEntity
import os

class CollisionManager(Node):
    def __init__(self):
        super().__init__('collision_manager')

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)

        self.spawn_cli = self.create_client(SpawnEntity, '/spawn_entity')
        self.delete_cli = self.create_client(DeleteEntity, '/delete_entity')

        self.obstacle_name = 'cubo'
        self.obstacle_spawned = False
        self.obstacle_deleted = False
        self.robot_stopped = False
        self.delete_timer = None

        self.timer = self.create_timer(0.1, self.move_forward)
        self.cubo_path = '/home/leyre/cubo.sdf'

        self.spawn_obstacle()

    def spawn_obstacle(self):
        if not os.path.exists(self.cubo_path):
            self.get_logger().error(f'Archivo SDF no encontrado: {self.cubo_path}')
            return

        while not self.spawn_cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Esperando servicio /spawn_entity...')

        req = SpawnEntity.Request()
        req.name = self.obstacle_name
        req.xml = open(self.cubo_path, 'r').read()
        req.robot_namespace = ''
        req.initial_pose.position.x = 1.0
        req.initial_pose.position.y = -0.5
        req.initial_pose.position.z = 0.0
        req.initial_pose.orientation.w = 1.0

        self.spawn_cli.call_async(req)
        self.obstacle_spawned = True
        self.get_logger().info('Cubo insertado frente al robot.')

    def schedule_obstacle_deletion(self):
        if not self.obstacle_deleted and self.delete_timer is None:
            self.get_logger().info('Programando eliminación del cubo en 3 segundos...')
            self.delete_timer = self.create_timer(3.0, self.delete_obstacle)

    def delete_obstacle(self):
        if not self.obstacle_deleted:
            while not self.delete_cli.wait_for_service(timeout_sec=1.0):
                self.get_logger().info('Esperando servicio /delete_entity...')
            req = DeleteEntity.Request()
            req.name = self.obstacle_name
            self.delete_cli.call_async(req)
            self.obstacle_deleted = True
            self.get_logger().info('Cubo eliminado.')
            if self.delete_timer:
                self.delete_timer.cancel()
                self.delete_timer = None

    def scan_callback(self, msg):
        front = msg.ranges[0:20]
        valid_ranges = [r for r in front if r > 0.0 and r < float('inf')]

        if valid_ranges:
            min_dist = min(valid_ranges)
            if min_dist < 0.5 and not self.robot_stopped:
                self.get_logger().info(f'Obstáculo a {min_dist:.2f} m. Deteniendo robot.')
                self.robot_stopped = True
                self.stop_robot()
                self.schedule_obstacle_deletion()

        # Reanudar marcha si el cubo fue eliminado y el robot está detenido
        if self.robot_stopped and self.obstacle_deleted:
            self.get_logger().info('Cubo eliminado. Reanudando marcha.')
            self.robot_stopped = False

    def move_forward(self):
        if not self.robot_stopped:
            twist = Twist()
            twist.linear.x = 0.2
            self.cmd_pub.publish(twist)

    def stop_robot(self):
        twist = Twist()
        twist.linear.x = 0.0
        for _ in range(10):
            self.cmd_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = CollisionManager()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

