import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from gazebo_msgs.srv import SpawnEntity
import os

class TrayectoryObstacle(Node):
    def __init__(self):
        super().__init__('trayectory_obstacle')

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.spawn_cli = self.create_client(SpawnEntity, '/spawn_entity')

        self.timer = self.create_timer(0.1, self.move_robot)

        self.obstacle_name = 'cubo'
        self.obstacle_spawned = False
        self.cubo_path = '/home/leyre/cubo.sdf'

        self.evasion_mode = False
        self.correction_mode = False
        self.turn_direction = 0.0
        self.last_turn_direction = 0.0
        self.angular_speed = 0.22
        self.linear_speed = 0.18
        self.correction_timer = 0.0
        self.correction_duration = 4.0  # más tiempo para corregir

        self.spawn_obstacle()

    def spawn_obstacle(self):
        if not os.path.exists(self.cubo_path):
            self.get_logger().error(f'Archivo SDF no encontrado: {self.cubo_path}')
            return

        while not self.spawn_cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Esperando servicio /spawn_entity...')

        req = SpawnEntity.Request()
        req.name = self.obstacle_name
        req.xml = open(self.cubo_path, 'r').read()
        req.robot_namespace = ''
        req.initial_pose.position.x = 1.0
        req.initial_pose.position.y = -0.5
        req.initial_pose.position.z = 0.0
        req.initial_pose.orientation.w = 1.0

        self.spawn_cli.call_async(req)
        self.obstacle_spawned = True
        self.get_logger().info('Cubo insertado en posición lateral.')

    def scan_callback(self, msg):
        ranges = msg.ranges

        # Campo frontal ampliado: -30° a +30°
        front = ranges[0:30] + ranges[-30:]
        left = ranges[60:90]
        right = ranges[90:120]

        front_valid = [r for r in front if r > 0.0 and r < float('inf')]
        left_valid = [r for r in left if r > 0.0 and r < float('inf')]
        right_valid = [r for r in right if r > 0.0 and r < float('inf')]

        min_front = min(front_valid) if front_valid else float('inf')
        min_left = min(left_valid) if left_valid else float('inf')
        min_right = min(right_valid) if right_valid else float('inf')

        if min_front < 1.0:
            if not self.evasion_mode:
                self.get_logger().info('Obstáculo detectado. Iniciando evasión.')
            self.evasion_mode = True
            self.correction_mode = False
            if min_left > min_right:
                self.turn_direction = 1.0
            else:
                self.turn_direction = -1.0
            self.last_turn_direction = self.turn_direction
        else:
            if self.evasion_mode:
                self.get_logger().info('Cubo esquivado. Iniciando corrección.')
                self.evasion_mode = False
                self.correction_mode = True
                self.correction_timer = 0.0
                self.turn_direction = -self.last_turn_direction

    def move_robot(self):
        twist = Twist()
        twist.linear.x = self.linear_speed

        if self.correction_mode:
            self.correction_timer += 0.1
            if self.correction_timer >= self.correction_duration:
                self.correction_mode = False
                self.turn_direction = 0.0
                self.get_logger().info('Corrección completada. Reanudando marcha recta.')

        twist.angular.z = self.turn_direction * self.angular_speed
        self.cmd_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = TrayectoryObstacle()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

