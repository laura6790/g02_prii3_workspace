import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_nav2_bringup = get_package_share_directory('nav2_bringup')
    pkg_my_robot = get_package_share_directory('g02_prii3_move_jetbot')

    # Mapas y configuración RViz relativos al paquete
    map_yaml = os.path.join(pkg_my_robot, 'maps', 'f1l3.yaml')
    rviz_config = os.path.join(pkg_my_robot, 'rviz', 'nav2_default_view.rviz')

    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_nav2_bringup, 'launch', 'bringup_launch.py')
            ),
            launch_arguments={
                'map': map_yaml,
                'use_sim_time': 'true',
                'rviz_config': rviz_config
            }.items(),
        ),
    ])

