#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_srvs.srv import Empty

class TurtleBot3Controller(Node):
    def __init__(self):
        super().__init__('turtlebot3_controller')
        
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        
        self.stop_service = self.create_service(Empty, 'stop_drawing', self.stop_callback)
        self.resume_service = self.create_service(Empty, 'resume_drawing', self.resume_callback)
        self.reset_service = self.create_service(Empty, 'reset_drawing', self.reset_callback)
        
        self.is_drawing = True
        self.step = 0
        self.movements = self.generate_number_2_movements()
        
        self.timer = self.create_timer(1.0, self.timer_callback)
        
        self.get_logger().info('=== Nodo TurtleBot3 inicializado ===')
        self.get_logger().info('Servicios disponibles:')
        self.get_logger().info('  /stop_drawing - Detiene el movimiento')
        self.get_logger().info('  /resume_drawing - Reanuda el movimiento')
        self.get_logger().info('  /reset_drawing - Reinicia la secuencia')
        
    def generate_number_2_movements(self):
        movements = []
        for _ in range(6):
            movements.append((0.0, 0.25))
        for _ in range(7):
            movements.append((0.4, -0.55))
        for _ in range(4):
            movements.append((0.5, 0.0))
        for _ in range(6):
            movements.append((0.0, 0.4))
        for _ in range(4):
            movements.append((0.5, 0.0))
        return movements
    
    def timer_callback(self):
        if not self.is_drawing or self.step >= len(self.movements):
            return
            
        linear, angular = self.movements[self.step]
        msg = Twist()
        msg.linear.x = linear
        msg.angular.z = angular
        self.publisher_.publish(msg)
        
        self.get_logger().info(f'Paso {self.step+1}/{len(self.movements)}')
        self.step += 1
        
        if self.step >= len(self.movements):
            self.get_logger().info('¡Secuencia completada!')
    
    def stop_callback(self, request, response):
        self.is_drawing = False
        self.get_logger().info('Movimiento detenido')
        return response
    
    def resume_callback(self, request, response):
        self.is_drawing = True
        self.get_logger().info('Movimiento reanudado')
        return response
    
    def reset_callback(self, request, response):
        self.step = 0
        self.is_drawing = True
        stop_msg = Twist()
        stop_msg.linear.x = 0.0
        stop_msg.angular.z = 0.0
        self.publisher_.publish(stop_msg)
        self.get_logger().info('Secuencia reiniciada')
        return response

def main(args=None):
    rclpy.init(args=args)
    node = TurtleBot3Controller()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

