import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    # Ruta al mapa F1L3
    map_file = os.path.join(
        get_package_share_directory('g02_prii3_move_jetbot'),
        'maps',
        'f1l3.yaml'
    )

    # Archivo de parámetros de Nav2 (puedes crear uno propio si quieres personalizar)
    params_file = LaunchConfiguration(
        'params_file',
        default=os.path.join(
            get_package_share_directory('nav2_bringup'),
            'params',
            'nav2_params.yaml'
        )
    )

    nav2_bringup_dir = get_package_share_directory('nav2_bringup')
    rviz_config_file = os.path.join(nav2_bringup_dir, 'rviz', 'nav2_default_view.rviz')

    return LaunchDescription([
        # Bringup de Nav2 (incluye planner, controller, lifecycle manager y AMCL)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(nav2_bringup_dir, 'launch', 'bringup_launch.py')
            ),
            launch_arguments={
                'map': map_file,
                'use_sim_time': use_sim_time,
                'params_file': params_file
            }.items(),
        ),
        # RViz con configuración estándar
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(nav2_bringup_dir, 'launch', 'rviz_launch.py')
            ),
            launch_arguments={'rviz_config_file': rviz_config_file}.items(),
        ),
    ])

