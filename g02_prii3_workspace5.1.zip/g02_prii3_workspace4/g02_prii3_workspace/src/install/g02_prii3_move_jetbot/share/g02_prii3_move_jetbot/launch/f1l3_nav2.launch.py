import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import Node


def generate_launch_description():
    pkg_nav2_bringup = get_package_share_directory('nav2_bringup')
    pkg_my_robot = get_package_share_directory('g02_prii3_move_jetbot')

    # Mapas y configuración RViz relativos al paquete
    map_yaml = os.path.join(pkg_my_robot, 'maps', 'f1l3.yaml')
    rviz_config = os.path.join(pkg_my_robot, 'rviz', 'nav2_default_view.rviz')

    # Publica pose inicial automáticamente (ajusta coordenadas si cambias el spawn)
    publish_initial_pose = ExecuteProcess(
        cmd=[
            'ros2', 'topic', 'pub', '/initialpose',
            'geometry_msgs/PoseWithCovarianceStamped', '--once',
            '{header: {frame_id: "map"}, '
            'pose: {pose: {position: {x: 5.0, y: 2.4, z: 0.0}, '
            'orientation: {z: 0.0, w: 1.0}}, '
            'covariance: [0.25, 0, 0, 0, 0, 0, '
            '0, 0.25, 0, 0, 0, 0, '
            '0, 0, 0.0001, 0, 0, 0, '
            '0, 0, 0, 0.0001, 0, 0, '
            '0, 0, 0, 0, 0.0001, 0, '
            '0, 0, 0, 0, 0, 0.25]} }'
        ],
        output='screen'
    )

    return LaunchDescription([
        # Nav2 Bringup
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_nav2_bringup, 'launch', 'bringup_launch.py')
            ),
            launch_arguments={
                'map': map_yaml,
                'use_sim_time': 'true',
                'autostart': 'true'
            }.items(),
        ),

        # RViz explícito con tu configuración
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', rviz_config],
            parameters=[{'use_sim_time': True}]
        ),

        # Publica pose inicial para que AMCL arranque
        publish_initial_pose,
    ])

