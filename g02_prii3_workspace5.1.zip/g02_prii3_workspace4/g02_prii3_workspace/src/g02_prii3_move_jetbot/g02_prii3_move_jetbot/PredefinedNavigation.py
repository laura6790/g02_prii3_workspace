import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient


class PredefinedNavigation(Node):
    def __init__(self):
        super().__init__('predefined_navigation')

        # Cliente de acción para Nav2
        self._action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self._action_client.wait_for_server()

        # Publicador de pose inicial (para simulación)
        self.initial_pose_pub = self.create_publisher(PoseWithCovarianceStamped, 'initialpose', 10)
        self.publish_initial_pose(0.0, 0.0, 0.0)

        # Definir destino predefinido en el mapa F1L3
        goal_pose = self.create_pose(2.0, 1.5, 0.0)
        self.send_goal(goal_pose)

    def publish_initial_pose(self, x, y, yaw):
        pose = PoseWithCovarianceStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.pose.position.x = x
        pose.pose.pose.position.y = y
        pose.pose.pose.orientation.w = 1.0  # orientación simple
        self.initial_pose_pub.publish(pose)
        self.get_logger().info(f'Pose inicial publicada en ({x}, {y})')

    def create_pose(self, x, y, yaw):
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = x
        pose.pose.position.y = y
        pose.pose.orientation.w = 1.0
        return pose

    def send_goal(self, pose):
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = pose
        self.get_logger().info(f'Enviando objetivo: x={pose.pose.position.x}, y={pose.pose.position.y}')
        self._action_client.send_goal_async(goal_msg)


def main(args=None):
    rclpy.init(args=args)
    node = PredefinedNavigation()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

