from geometry_msgs.msg import PoseStamped
import rclpy
from rclpy.node import Node
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient

class PredefinedNavigation(Node):
    def __init__(self):
        super().__init__('predefined_navigation')
        self._client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

    def send_goal(self):
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = PoseStamped()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()

        # Pose final predefinida (ejemplo)
        goal_msg.pose.pose.position.x = 2.0
        goal_msg.pose.pose.position.y = 1.0
        goal_msg.pose.pose.orientation.w = 1.0

        self._client.wait_for_server()
        self._client.send_goal_async(goal_msg)

def main(args=None):
    rclpy.init(args=args)
    node = PredefinedNavigation()
    node.send_goal()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

